SAS-Rapportino Android - progetto di confezionamento iniziale

Contenuto:
- HTML sorgente: app/src/main/assets/index.html (versione v1.0-pausa-corretta recuperata dalla Libreria)
- logo SAS originale incorporato nell'HTML: logo-sas.png e icona launcher generata da quel marchio
- contenitore Android WebView offline con JavaScript e DOM storage abilitati
- workflow GitHub Actions per compilare un APK debug e pubblicarlo come artifact

IMPORTANTE
Questo è il progetto sorgente, NON un APK già compilato o testato.
Non sono ancora state implementate/verificate in questa confezione le funzioni native di esportazione/ripristino backup, archivio PDF e invio differito email. I dati WebView restano nell'area privata dell'app, ma Android li elimina alla disinstallazione: prima dell'uso reale serve backup/restore verificato.
Prima della distribuzione vanno eseguiti test reali su Motorola Edge 50 Fusion / Android 16: salvataggio e riapertura dati, generazione PDF, stampa/condivisione, rotazione e flussi di pausa.

Compilazione remota: caricare l'intero contenuto di questa cartella in un nuovo repository GitHub e avviare Actions > Build SAS-Rapportino APK. Il file app-debug.apk apparirà tra gli artifact della run.
